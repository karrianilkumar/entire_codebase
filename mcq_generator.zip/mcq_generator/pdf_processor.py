import pdfplumber
import PyPDF2
from pdfminer.high_level import extract_text

def extract_text_from_pdf(pdf_path):
    """Extract text from PDF using multiple methods"""
    text = ""
    
    # Method 1: pdfplumber
    try:
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                text += page.extract_text() + "\n"
    except:
        pass
    
    # Method 2: PyPDF2
    if not text.strip():
        try:
            with open(pdf_path, 'rb') as file:
                reader = PyPDF2.PdfReader(file)
                for page in reader.pages:
                    text += page.extract_text() + "\n"
        except:
            pass
    
    # Method 3: pdfminer
    if not text.strip():
        try:
            text = extract_text(pdf_path)
        except:
            pass
    
    if not text.strip():
        raise ValueError("Could not extract text from PDF")
    
    return text