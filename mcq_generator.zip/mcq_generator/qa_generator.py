from transformers import pipeline
import random
import re

# Load models from Hugging Face
qa_pipeline = pipeline("question-answering", model="deepset/roberta-base-squad2")
summarizer = pipeline("summarization", model="facebook/bart-large-cnn")

def generate_questions(text, num_mcqs=5, num_qnas=5):
    # Shorten text if too long
    if len(text) > 3000:
        text = summarizer(text[:3000], max_length=1024, min_length=50, do_sample=False)[0]['summary_text']

    sentences = [s.strip() for s in re.split(r'(?<=[.!?]) +', text) if len(s.strip()) > 20]
    if len(sentences) < num_mcqs + num_qnas:
        sentences = sentences * 2  # duplicate to fill

    selected_sentences = random.sample(sentences, num_mcqs + num_qnas)

    mcqs = []
    qnas = []

    for idx, sentence in enumerate(selected_sentences[:num_mcqs]):
        words = sentence.split()
        if len(words) < 5:
            continue
        answer = random.choice(words)
        question = sentence.replace(answer, "_____")
        options = [answer] + random.sample(words, k=3)
        random.shuffle(options)
        correct_letter = 'abcd'[options.index(answer)]

        mcqs.append({
            'question': question,
            'options': [f"{opt}" for opt in options],
            'correct': correct_letter
        })

    for idx, sentence in enumerate(selected_sentences[num_mcqs:num_mcqs + num_qnas]):
        qa_input = {
            'question': f"What is meant by: '{sentence[:50]}...'",
            'context': text
        }
        result = qa_pipeline(qa_input)
        if result and result.get("answer"):
            qnas.append({
                'question': qa_input['question'],
                'answer': result['answer']
            })

    return mcqs, qnas



# qg_pipeline = pipeline("text2text-generation", model="valhalla/t5-small-e2e-qg")

# from transformers import pipeline

# qg_pipeline = pipeline("text2text-generation", model="mrm8488/t5-base-finetuned-question-generation-ap")



# from transformers import pipeline

# # Compatible model without SentencePiece
# qg_pipeline = pipeline("text2text-generation", model="mrm8488/t5-base-finetuned-question-generation-ap")

# def generate_questions(text, num_mcqs=5, num_qnas=5):
#     max_chars = 2000
#     text = text[:max_chars]

#     prompt = f"generate question: {text}"
    
#     total_needed = (num_mcqs + num_qnas) * 2
#     result = qg_pipeline(
#         prompt,
#         max_length=128,
#         do_sample=True,
#         top_p=0.95,
#         top_k=50,
#         num_return_sequences=total_needed
#     )

#     questions = list({r["generated_text"].strip() for r in result})
#     mcqs = []
#     qnas = []

#     for q in questions:
#         if len(mcqs) >= num_mcqs and len(qnas) >= num_qnas:
#             break
#         elif '?' in q and len(mcqs) < num_mcqs:
#             mcqs.append({
#                 'question': q,
#                 'options': ['Option A', 'Option B', 'Option C', 'Option D'],
#                 'correct': 'a'
#             })
#         elif len(qnas) < num_qnas:
#             qnas.append({'question': q, 'answer': 'Answer TBD'})

#     return mcqs, qnas
