# import os
# from flask import Flask, render_template, request, redirect, url_for, flash
# from werkzeug.utils import secure_filename
# from pdf_processor import extract_text_from_pdf
# from question_generator import generate_questions
# from config import Config

# app = Flask(__name__)
# app.config.from_object(Config)

# # Ensure upload folder exists
# os.makedirs('uploads', exist_ok=True)

# @app.route('/', methods=['GET', 'POST'])
# def index():
#     if request.method == 'POST':
#         if 'file' not in request.files:
#             flash('No file selected')
#             return redirect(request.url)

#         file = request.files['file']
#         num_mcqs = request.form.get('num_mcqs', type=int)
#         num_qnas = request.form.get('num_qnas', type=int)

#         if file.filename == '':
#             flash('No file selected')
#             return redirect(request.url)

#         if file and allowed_file(file.filename):
#             filename = secure_filename(file.filename)
#             filepath = os.path.join('uploads', filename)
#             file.save(filepath)

#             try:
#                 text = extract_text_from_pdf(filepath)
#                 mcqs, qnas = generate_questions(text, num_mcqs=num_mcqs, num_qnas=num_qnas)
#                 return render_template('results.html',
#                                        mcqs=mcqs,
#                                        qnas=qnas,
#                                        filename=filename)
#             except Exception as e:
#                 flash(f'Error processing file: {str(e)}')
#                 return redirect(request.url)

#     return render_template('index.html')

# def allowed_file(filename):
#     return '.' in filename and \
#            filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

# if __name__ == '__main__':
#     app.run(debug=True)





from flask import Flask, render_template, request, redirect, url_for
import os
from werkzeug.utils import secure_filename
from qa_generator import generate_questions

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/signup')
def signup():
    return render_template('signup.html')


@app.route('/login')
def login():
    return render_template('login.html')


@app.route('/home', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        return redirect(url_for('home'))
    return render_template('home.html')


@app.route('/upload', methods=['POST'])
def upload():
    file = request.files['file']
    num_mcqs = int(request.form['num_mcqs'])
    num_qa = int(request.form['num_qa'])

    if file and file.filename.endswith('.pdf'):
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(file.filename))
        file.save(filepath)

        # Use pdfplumber to extract text (assuming this is already implemented in your logic)
        import pdfplumber
        with pdfplumber.open(filepath) as pdf:
            text = '\n'.join(page.extract_text() for page in pdf.pages if page.extract_text())

        mcqs, qa_pairs = generate_questions(text, num_mcqs=num_mcqs, num_qnas=num_qa)

        return render_template('results.html', mcqs=mcqs, qa_pairs=qa_pairs)

    return "Invalid file type", 400


if __name__ == '__main__':
    app.run(debug=True)
