import os

class Config:
    SECRET_KEY = 'your-secret-key-here'
    UPLOAD_FOLDER = 'uploads'
    ALLOWED_EXTENSIONS = {'pdf'}
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB

    # AI Configuration
    OPENAI_API_KEY = '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'
    QUESTION_MODEL = "gpt-3.5-turbo"
